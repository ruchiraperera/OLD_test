# WebApi.Jwt
Authentication for ASP.NET Web Api using simple JWT
