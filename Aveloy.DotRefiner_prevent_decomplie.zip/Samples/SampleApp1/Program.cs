﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

using SampleLib1;

namespace SampleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			var tmp = new Class1();
			using (var stream = new MemoryStream())
			{
				var serializer = new XmlSerializer(typeof(Class1));
				serializer.Serialize(stream, tmp);
				Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer()));
			}

			Console.WriteLine(new string('-', 80));

			var tmp2 = new Class2();
			Console.WriteLine(nameof(tmp2.Field1));
			Console.WriteLine(typeof(Class2).GetFields().First().Name);

			if (Debugger.IsAttached)
				Debugger.Break();
		}
	}
}
