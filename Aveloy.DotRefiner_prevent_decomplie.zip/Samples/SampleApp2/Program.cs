﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

using SampleLib1;

namespace SampleApp2
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				var tmp2 = new StackClass1();
				tmp2.TestMethod();
			}
			catch (ApplicationException exc)
			{
				Console.WriteLine(exc);
			}

			if (Debugger.IsAttached)
				Debugger.Break();
		}
	}
}
